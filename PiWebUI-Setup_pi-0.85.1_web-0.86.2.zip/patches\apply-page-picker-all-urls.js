#!/usr/bin/env node
/**
 * page-picker 浏览器扩展：放行「所有网站」（AI 可操作任意 http/https 页面）。
 *
 * 官方扩展有两道闸门，默认都要逐个站点人工授权：
 *   1) manifest.json 的 host_permissions 只含 http://localhost/* 与 http://127.0.0.1/*，
 *      其它站点是 optional_host_permissions —— 没有 host 权限时 chrome.scripting
 *      根本注入不进去；
 *   2) 扩展自己维护的白名单 chrome.storage.local 的 aiPages（选项页「AI 操作页面」
 *      里逐条授权），decideAiRoute() 会拒绝不在表里的 origin。
 *
 * 本补丁把两道闸门都打开：host_permissions 扩到全站，并让 decideAiRoute() 在
 * 「模型明确指定了 target」时直接放行任意 http/https 页面。
 *
 * 安全提醒：这会让你打开的**任何**网站都成为「已被授权给 AI 的页面」——
 * 包括邮箱、网盘、后台管理系统。装在生产/共用机器上前请三思。
 *
 * 幂等；由 install-plugins.js 之外的流程手动执行；改完要在 edge://extensions
 * 里点该扩展的「重新加载」才生效（Edge 可能要求确认新增权限）。
 * 想恢复官方行为：清空 extension/ 后用 page-picker.zip 重新解压即可。
 *
 * 用法：node patches/apply-page-picker-all-urls.js [--dir <扩展目录>]
 */
const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "..");
const dirFlag = process.argv.indexOf("--dir");
const extDir =
	dirFlag >= 0 ? path.resolve(process.argv[dirFlag + 1]) : path.join(root, "projects", "page-picker-extension", "extension");
const marker = "page-picker-all-urls";
const ALL_URLS = ["http://*/*", "https://*/*"];

const manifestFile = path.join(extDir, "manifest.json");
const bgFile = path.join(extDir, "dist", "background.js");

if (!fs.existsSync(manifestFile) || !fs.existsSync(bgFile)) {
	console.error(`✗ 找不到扩展文件：${manifestFile} / ${bgFile}`);
	console.error("  先在 projects/page-picker-extension/ 里解压官方 page-picker-extension.zip。");
	process.exit(1);
}

// ---- 1. manifest：host_permissions 扩到全站 ----
let manifest;
try {
	manifest = JSON.parse(fs.readFileSync(manifestFile, "utf8"));
} catch (err) {
	console.error(`✗ manifest.json 解析失败：${err.message}`);
	process.exit(1);
}
const hosts = Array.isArray(manifest.host_permissions) ? manifest.host_permissions : [];
if (hosts.includes("http://*/*") && hosts.includes("https://*/*")) {
	console.log("✓ manifest 已是全站权限，跳过");
} else {
	manifest.host_permissions = ALL_URLS;
	// tab 缩进与官方一致（官方 manifest 用 tab），且不能带 BOM
	fs.writeFileSync(manifestFile, JSON.stringify(manifest, null, "\t") + "\n", "utf8");
	console.log(`✓ manifest.host_permissions → ${ALL_URLS.join(", ")}`);
}

// ---- 2. background.js：decideAiRoute 全站放行 ----
let bg = fs.readFileSync(bgFile, "utf8");
if (bg.includes(marker)) {
	console.log("✓ background.js 已含全站放行补丁，跳过");
	process.exit(0);
}
// 锚点必须唯一：只出现在 decideAiRoute() 里出现的这一行
const needle = `  if (aiPages.length === 0) {`;
const count = bg.split(needle).length - 1;
if (count !== 1) {
	console.error(`✗ 锚点出现 ${count} 次（应为 1 次），扩展版本可能已变化，未改动 background.js`);
	process.exit(2);
}
const replacement =
	`  /* ${marker}: 全站放行 —— 模型指定 target 时，任意 http/https 页面都当作已授权给 AI。 */\n` +
	`  if (want) return { ok: true, page: { origin: want, title: want }, peer: want };\n` +
	needle;
bg = bg.replace(needle, replacement);
fs.writeFileSync(bgFile, bg, "utf8");
console.log("✓ background.js 已插入全站放行（decideAiRoute）");
console.log("\n下一步：到 edge://extensions 点该扩展的「重新加载」（Edge 可能要求确认新增的网站访问权限）。");
