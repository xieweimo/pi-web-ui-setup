#!/usr/bin/env node
/** [[plan:...]] 补丁的服务端全链路 mock 测试。 */
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
const { findWebUiRoot } = require("./pi-web-ui-locate.js");
const webRoot = findWebUiRoot();
assert.ok(webRoot, "找不到 pi-web-ui 安装目录");
const serverRoot = path.join(webRoot, "dist", "server");
const { MarkerService } = await import(pathToFileURL(path.join(serverRoot, "marker-service.js")).href);
const { PlanManager } = await import(pathToFileURL(path.join(serverRoot, "plan-manager.js")).href);

const emitted = [];
const settings = { markersEnabled: true, disabledMarkers: [] };

// 模拟 SDK 会话文件：appendCustomEntry 落盘、getBranch 读回，
// 这样「写快照 → 重启后回填」的闭环能真跑一遍，而不是靠 mock 假装成功。
const branch = [];
const sessionManager = {
	appendCustomEntry: (customType, data) => { branch.push({ type: "custom", customType, data }); },
	getBranch: () => branch,
};
const snapshots = () => branch
	.filter((e) => e.customType === "marker-tools/store" && e.data?.namespace === "plan")
	.map((e) => e.data.state);

function makeHost() {
	return {
		clientId: "test",
		stateStore: {
			getMarkerSettings: () => ({ ...settings }),
			saveMarkerSettings: () => {},
		},
		planManager: new PlanManager(),
		getSessionManager: () => sessionManager,
		lang: () => "zh",
		emit: (message) => emitted.push(message),
		refreshMarkers: () => {},
		renameConversation: () => {},
		flushSnapshot: () => {},
	};
}

// 防回归：mock 给 host 注入 planManager 不能证明真实 AgentService 也做了这件事。
const agentService = await fs.readFile(
	path.join(serverRoot, "agent-service.js"),
	"utf8",
);
assert.match(
	agentService,
	/this\.markerSvc = new MarkerService\(\{[\s\S]*?planManager: this\.planManager,[\s\S]*?flushSnapshot: \(\) => this\.flushSnapshot\(\),/,
	"AgentService 必须把 planManager 与 flushSnapshot 注入 MarkerService host",
);

const host = makeHost();
const markers = new MarkerService(host);

await markers.handleAssistantText("conv", "[[plan:new:1=调研,2=实现,3=验证,active=1]]");
let plan = host.planManager.getPlan("conv");
assert.deepEqual(plan.steps.map((s) => [s.id, s.title, s.status]), [
	["1", "调研", "in_progress"],
	["2", "实现", "pending"],
	["3", "验证", "pending"],
]);
assert.equal(plan.activeStepId, "1");

// 回归截图中的错误写法：状态被塞进标题时必须拒绝，且不能污染当前看板。
await markers.handleAssistantText("conv", "[[plan:new:1=确认迁移边界=done,2=完成实施方案=done,active=1]]");
plan = host.planManager.getPlan("conv");
assert.deepEqual(plan.steps.map((s) => [s.id, s.title, s.status]), [
	["1", "调研", "in_progress"],
	["2", "实现", "pending"],
	["3", "验证", "pending"],
]);

await markers.handleAssistantText("conv", "[[plan:set:1=done,2=in_progress,active=2]]");
plan = host.planManager.getPlan("conv");
assert.deepEqual(plan.steps.map((s) => s.status), ["done", "in_progress", "pending"]);
assert.equal(plan.activeStepId, "2");

await markers.handleAssistantText("conv", "[[plan:set:2=done,3=done]]");
plan = host.planManager.getPlan("conv");
assert.deepEqual(plan.steps.map((s) => s.status), ["done", "done", "done"]);
assert.equal(plan.activeStepId, null);
assert.equal(emitted.filter((m) => m.type === "plan_updated").length, 3);

// 快照必须存真实步骤，而不是空对象（曾把 {} 当状态落盘，重启即丢看板）。
const snaps = snapshots();
assert.ok(snaps.length >= 3, `plan 标记必须落快照，实际 ${snaps.length} 条`);
assert.deepEqual(snaps[snaps.length - 1].steps.map((s) => [s.id, s.status]), [
	["1", "done"],
	["2", "done"],
	["3", "done"],
]);
assert.equal(snaps[snaps.length - 1].activeStepId, null);

// 模拟服务重启：PlanManager 内存清空，只能靠会话快照回填。
const host2 = makeHost();
const markers2 = new MarkerService(host2);
assert.equal(host2.planManager.getPlan("conv"), null);
await markers2.handleAssistantText("conv", "[[plan:set:3=in_progress,active=3]]");
const recovered = host2.planManager.getPlan("conv");
assert.deepEqual(recovered.steps.map((s) => [s.id, s.status]), [
	["1", "done"],
	["2", "done"],
	["3", "in_progress"],
]);
assert.equal(recovered.activeStepId, "3");

// 清空后重启不得复活旧看板。
await markers2.handleAssistantText("conv", "[[plan:clear:now]]");
const host3 = makeHost();
const markers3 = new MarkerService(host3);
await markers3.handleAssistantText("conv", "[[plan:new:1=重来,active=1]]");
assert.deepEqual(host3.planManager.getPlan("conv").steps.map((s) => [s.id, s.title]), [["1", "重来"]]);

// 页面加载时的回填链：AgentService 下发的快照必须带 plan，且重启后必须真有一条回填通路。
// 0.99.0 起上游自己持久化计划（PlanManager 落盘 plans.json + bindSession 回填），我们原先注入的
// restorePlanFromSnapshot / plan-marker-legacy-status-migration-v4 已随之退役（见 patches/
// patch-pi-web-ui-plan-marker.js 注释、scripts/check-pi-web-ui-patches.js 第 56-60 行）。
// 所以这里断言「当前架构下回填链完整」，不再钉死某一种实现：
//   1) 快照里必须直出 getPlan（上游 `?? null` 与我们 `?? restorePlanFromSnapshot(...)` 两种写法都算）；
//   2) 上游落盘回填（plans.json + bindSession）或我们注入的 restorePlanFromSnapshot 至少存在一个。
assert.match(
	agentService,
	/plan: this\.planManager\.getPlan\(this\.activeId\)/,
	"AgentService 下发状态时必须带上看板（getPlan 直出，或 ??? restorePlanFromSnapshot 兜底）",
);
const planManagerSrc = await fs.readFile(path.join(serverRoot, "plan-manager.js"), "utf8");
const upstreamPlanPersistence =
	/plans\.json/.test(planManagerSrc) && /bindSession\(conversationId, sessionId\)/.test(planManagerSrc);
const ownSnapshotRestore = /restorePlanFromSnapshot/.test(agentService);
assert.ok(
	upstreamPlanPersistence || ownSnapshotRestore,
	"重启后必须能回填看板：上游 plans.json 落盘 + bindSession，或我们注入的 restorePlanFromSnapshot 至少存在一个",
);
// 旧脏标题（把 =done 写进 title）的历史迁移断言已随上游接管退役：现在由 plan:new 的严格语法校验
// 在写入侧拦住（见上面「状态塞进标题必须拒绝」那条断言）。
const rawForRestore = markers3.getRawState("conv", "plan");
assert.ok(
	Array.isArray(rawForRestore?.steps) && rawForRestore.steps.length === 1,
	"getRawState 必须能从会话快照读回步骤",
);
const restoredManager = new PlanManager();
restoredManager.setPlan("conv", rawForRestore.steps, rawForRestore.activeStepId ?? undefined);
assert.deepEqual(restoredManager.getPlan("conv").steps.map((s) => [s.id, s.title]), [["1", "重来"]]);

console.log("✓ [[plan:...]] marker：新建、更新、完成、清空、快照持久化与重启恢复全部通过");
