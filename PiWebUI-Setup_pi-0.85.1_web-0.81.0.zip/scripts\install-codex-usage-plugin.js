#!/usr/bin/env node
/**
 * 把 codex-usage 插件部署到 pi-web-ui 的数据目录。
 *
 * 源：<本仓库>/projects/codex-usage-plugin
 * 目标：<dataDir>/plugins/codex-usage/（默认 ~/.pi-web/plugins/codex-usage）
 *
 * 用法：node scripts/install-codex-usage-plugin.js [--data-dir <dir>] [--dry-run]
 * 说明：只复制 manifest.json / index.mjs / client/ / README.md，跳过 tests/；
 *      pi-web-ui 升级不会动这个目录（插件目录与包目录分离）。
 */
const fs = require("fs");
const path = require("path");
const os = require("os");

const args = process.argv.slice(2);
const dryRun = args.includes("--dry-run");
const dataDirFlag = args.indexOf("--data-dir");

const SRC = path.join(__dirname, "..", "projects", "codex-usage-plugin");
const DATA_DIR =
	(dataDirFlag >= 0 ? args[dataDirFlag + 1] : process.env.PI_WEB_DATA_DIR) ||
	path.join(os.homedir(), ".pi-web");
const DEST = path.join(DATA_DIR, "plugins", "codex-usage");
const COPY = ["manifest.json", "index.mjs", "README.md", "client"];

function log(msg) {
	console.log(msg);
}

if (!fs.existsSync(SRC)) {
	console.error("✗ 找不到插件源码：" + SRC);
	process.exit(1);
}

log(`源：${SRC}`);
log(`目标：${DEST}`);
if (dryRun) {
	log("（--dry-run：只打印，不写入）");
	process.exit(0);
}

fs.mkdirSync(DEST, { recursive: true });
for (const item of COPY) {
	const from = path.join(SRC, item);
	if (!fs.existsSync(from)) continue;
	const to = path.join(DEST, item);
	if (fs.statSync(from).isDirectory()) fs.cpSync(from, to, { recursive: true });
	else fs.copyFileSync(from, to);
	log(`  ✓ ${item}`);
}

// 清理 pi-web-ui 的模块缓存不需要操作：服务端 reload（设置 → 界面插件 → 重载）或重启后生效
log("✓ 部署完成。刷新浏览器（Ctrl+F5）即可看到 ⚡ 标签；设置里可改显示模式/汇率/刷新间隔。");
