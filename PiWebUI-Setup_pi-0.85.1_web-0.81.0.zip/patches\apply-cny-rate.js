#!/usr/bin/env node
// 重新应用「人民币汇率」补丁（升级 pi-web-ui 后执行一次即可）
// 效果：网页端状态栏「累计成本」由美元 $ 改为人民币 ¥，汇率可配置
// 配置：改 web/dist/index.html 里的 window.__PI_USD_TO_CNY__（默认 7.2）
const fs = require('fs');
const path = require('path');

const DEFAULT_RATE = '7.2';
const webRoot = path.join(process.env.APPDATA || '', 'npm', 'node_modules', 'pi-web-ui', 'web', 'dist');
const htmlPath = path.join(webRoot, 'index.html');
const assetsDir = path.join(webRoot, 'assets');

function fail(msg) { console.error('✗ ' + msg); process.exit(1); }
function ok(msg) { console.log('✓ ' + msg); }

if (!fs.existsSync(htmlPath)) fail('未找到 ' + htmlPath);

// ---- 1. index.html 注入汇率配置 ----
let html = fs.readFileSync(htmlPath, 'utf8');
if (html.includes('__PI_USD_TO_CNY__')) {
  ok('index.html 已含汇率配置，跳过注入');
} else {
  const marker = '</head>';
  if (!html.includes(marker)) fail('index.html 未找到 </head>');
  const inject =
    "\t\t<script>\n" +
    "\t\t\t// 人民币汇率配置：1 美元 = ? 人民币（改这里的数字即可）\n" +
    "\t\t\twindow.__PI_USD_TO_CNY__ = " + DEFAULT_RATE + ";\n" +
    "\t\t</script>\n" +
    "\t" + marker;
  html = html.replace(marker, inject);
  fs.writeFileSync(htmlPath, html, 'utf8');
  ok('index.html 已注入汇率配置（默认 ' + DEFAULT_RATE + '）');
}

// ---- 2. 主 js：$ 改成 ¥，金额乘汇率 ----
const entry = fs.readdirSync(assetsDir).filter(f => /^index-.*\.js$/.test(f));
if (entry.length !== 1) fail('未找到唯一的主入口 js，找到：' + entry.join(', '));
const jsPath = path.join(assetsDir, entry[0]);

let js = fs.readFileSync(jsPath, 'utf8');
const OLD = '["$",Ff(me.cost)]';
const NEW = '["¥",Ff(me.cost*(window.__PI_USD_TO_CNY__||' + DEFAULT_RATE + '))]';
if (js.includes(NEW)) {
  ok('js 已替换过，跳过');
} else if (js.includes(OLD)) {
  js = js.split(OLD).join(NEW);
  fs.writeFileSync(jsPath, js, 'utf8');
  ok('js 已替换：$ → ¥（汇率 ' + DEFAULT_RATE + '）');
} else {
  fail('js 未找到目标字符串 ' + OLD + '（pi-web-ui 版本可能已变，需人工核对）');
}
ok('补丁完成。刷新网页（Ctrl+F5）即可看到人民币显示。');
