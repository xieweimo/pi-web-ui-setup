﻿# 重新应用 pi-web-ui 停止按钮补丁（升级 pi-web-ui 后执行一次即可）
# 作用：在 web/dist/index.html 的 </head> 前注入红色脉冲样式，让停止按钮更醒目
# 说明：本文件必须保存为「无 BOM 的 UTF-8」，且行尾为 LF，否则 PS 5.1 解析器会误判 here-string。
$ErrorActionPreference = 'Stop'
$html = Join-Path $env:APPDATA 'npm\node_modules\pi-web-ui\web\dist\index.html'

if (-not (Test-Path $html)) {
    Write-Host "未找到 $html" -ForegroundColor Red
    exit 1
}

$content = [System.IO.File]::ReadAllText($html, [System.Text.Encoding]::UTF8)

if ($content -match 'stopPulse') {
    Write-Host '补丁已存在，跳过。' -ForegroundColor Green
    exit 0
}

$css = @'
<style>
	/* 停止按钮增强：醒目红色 + 脉冲提示 */
	.btn.stop{background:#dc2626 !important;border-color:#dc2626 !important;color:#fff !important;box-shadow:0 0 0 0 rgba(220,38,38,.7) !important;animation:stopPulse 1.3s ease-in-out infinite}
	.btn.stop:hover:not(:disabled){background:#ef4444 !important;border-color:#ef4444 !important}
	@keyframes stopPulse{0%{box-shadow:0 0 0 0 rgba(220,38,38,.55)}70%{box-shadow:0 0 0 12px rgba(220,38,38,0)}100%{box-shadow:0 0 0 0 rgba(220,38,38,0)}}
</style>
'@

$content = $content -replace '</head>', ($css + "`n</head>")
# 必须无 BOM 写出：Set-Content -Encoding UTF8 在 PS 5.1 下会写入 EF BB BF
[System.IO.File]::WriteAllText($html, $content, (New-Object System.Text.UTF8Encoding($false)))
Write-Host '补丁已应用。' -ForegroundColor Green
