﻿# 重新应用 pi-web-ui 停止按钮补丁（升级 pi-web-ui 后执行一次即可）
# 作用：在 dist/index.html 的 </head> 前注入红色脉冲样式，让停止按钮更醒目
$html = Join-Path $env:APPDATA 'npm\node_modules\pi-web-ui\web\dist\index.html'

if (-not (Test-Path $html)) {
    Write-Host "未找到 $html" -ForegroundColor Red
    exit 1
}

$content = Get-Content -Raw -Encoding UTF8 $html

if ($content -match 'stopPulse') {
    Write-Host '补丁已存在，跳过。' -ForegroundColor Green
    exit 0
}

$css = @'
<style>
	/* 停止按钮增强：醒目红色 + 脉冲提示 */
	.btn.stop{background:#dc2626 !important;border-color:#dc2626 !important;color:#fff !important;box-shadow:0 0 0 0 rgba(220,38,38,.7) !important;animation:stopPulse 1.3s ease-in-out infinite}
	.btn.stop:hover:not(:disabled){background:#ef4444 !important;border-color:#ef4444 !important}
	@keyframes stopPulse{0%{box-shadow:0 0 0 0 rgba(220,38,38,.55)}70%{box-shadow:0 0 0 12px rgba(220,38,38,0)}100%{box-shadow:0 0 0 0 rgba(220,38,38,0)}}
</style>
'@

$content = $content -replace '</head>', ($css + "`n</head>")
Set-Content -Path $html -Value $content -Encoding UTF8 -NoNewline
Write-Host '补丁已应用。' -ForegroundColor Green
