#!/usr/bin/env node
/**
 * 隐藏「被 fork 掉的父会话」。
 *
 * pi-web-ui 的「编辑重问 / 重试」通过 fork 实现，每次都会新建一个会话文件并把
 * 上一代路径写进 header 的 parentSession。于是一次长对话可能变成
 * A → B → C → D 四个文件，历史列表里显示成四条同名记录。
 *
 * 本补丁让 pushSessions() 只列出「没有被任何其他会话当作父会话」的文件，
 * 也就是每个对话只显示最新的链尾，历史列表回归「一个对话一条」。
 *
 * 幂等；由启动器在服务启动前执行；源码不匹配时退出码 2 且不阻断服务。
 */
const fs = require("fs");
const { locateWebUiFile } = require("../scripts/pi-web-ui-locate.js");

const target = locateWebUiFile("dist", "server", "agent-service.js");
const marker = "hide-forked-sessions";

const importNeedle = `import { existsSync, readFileSync, rmSync, statSync, mkdirSync, watch } from "node:fs";`;
const importReplacement = `import { existsSync, readFileSync, rmSync, statSync, mkdirSync, watch, openSync, readSync, closeSync } from "node:fs"; // ${marker}`;

const listNeedle = `            const infos = await this.loadSessionInfos();
            const sessions = new Map();`;
const listReplacement = `            const infos = await this.loadSessionInfos();
            // ${marker}: 只保留 fork 链的链尾。编辑重问/重试每代都会新建一个会话文件并把
            // 上一代写进 parentSession，若不过滤，同一对话会在历史里显示成好几条。
            const forkedParentPaths = new Set();
            for (const info of infos) {
                try {
                    const fd = openSync(info.path, "r");
                    const buf = Buffer.alloc(4096);
                    const read = readSync(fd, buf, 0, 4096, 0);
                    closeSync(fd);
                    const head = JSON.parse(buf.subarray(0, read).toString("utf8").split("\\n", 1)[0]);
                    if (head && typeof head.parentSession === "string" && head.parentSession) {
                        forkedParentPaths.add(head.parentSession.toLowerCase());
                    }
                }
                catch {
                    /* 读不到的会话照常显示 */
                }
            }
            const visibleInfos = forkedParentPaths.size > 0
                ? (() => {
                    const kept = infos.filter((info) => !forkedParentPaths.has(info.path.toLowerCase()));
                    return kept.length > 0 ? kept : infos;
                })()
                : infos;
            const sessions = new Map();`;

const loopNeedle = `            for (const s of infos) {`;
const loopReplacement = `            for (const s of visibleInfos) {`;

if (!target || !fs.existsSync(target)) {
	console.error("✗ 找不到 pi-web-ui 的 dist/server/agent-service.js");
	process.exit(1);
}
let source = fs.readFileSync(target, "utf8");
if (source.includes(marker)) {
	console.log("✓ 隐藏 fork 父会话补丁已存在");
	process.exit(0);
}
if (!source.includes(importNeedle) || !source.includes(listNeedle) || !source.includes(loopNeedle)) {
	console.error("✗ pi-web-ui 版本的目标代码已变化，未应用 hide-forked-sessions 补丁");
	process.exit(2);
}
source = source.replace(importNeedle, importReplacement).replace(listNeedle, listReplacement).replace(loopNeedle, loopReplacement);
fs.writeFileSync(target, source, "utf8");
console.log("✓ 已应用 hide-forked-sessions 补丁");
