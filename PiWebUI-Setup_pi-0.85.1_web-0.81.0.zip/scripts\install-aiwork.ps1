param([switch]$SkipNpmInstall)
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$templateFile = Join-Path $root 'configs\pi-settings.template.json'
$agentDir = Join-Path $env:USERPROFILE '.pi\agent'
if (-not $SkipNpmInstall) { npm install -g '@earendil-works/pi-coding-agent@0.85.1' 'pi-web-ui@0.81.0' }
if (-not (Get-Command pi -ErrorAction SilentlyContinue) -or -not (Get-Command pi-web-ui -ErrorAction SilentlyContinue)) { throw 'pi or pi-web-ui was not found.' }
New-Item -ItemType Directory -Force -Path $agentDir | Out-Null
$template = Get-Content $templateFile -Raw -Encoding UTF8 | ConvertFrom-Json
$settingsFile = Join-Path $agentDir 'settings.json'
$current = if (Test-Path $settingsFile) { Get-Content $settingsFile -Raw -Encoding UTF8 | ConvertFrom-Json } else { [pscustomobject]@{} }
foreach ($p in $template.PSObject.Properties) { $current | Add-Member -Force NoteProperty $p.Name $p.Value }
# 必须写成「无 BOM」的 UTF-8：Windows PowerShell 5.1 的 Set-Content -Encoding UTF8
# 会写入 BOM(EF BB BF)，而 pi 用 Node 的 JSON.parse 读取 settings.json，遇到 BOM 会直接
# 报 "Unexpected token '', '{ "s"... is not valid JSON"（Failed to parse settings file）。
$json = $current | ConvertTo-Json -Depth 20
[System.IO.File]::WriteAllText($settingsFile, $json, (New-Object System.Text.UTF8Encoding($false)))
node (Join-Path $root 'scripts\install-codex-usage-plugin.js')
node (Join-Path $root 'scripts\apply-pi-web-ui-profile.js')
$launcher = Join-Path $root 'scripts\pi-web-ui-launcher.ps1'
$desktop = [Environment]::GetFolderPath('Desktop')
if (-not $desktop) { $desktop = Join-Path $env:USERPROFILE 'Desktop' }
New-Item -ItemType Directory -Force -Path $desktop | Out-Null
$shortcut = (New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $desktop 'Pi Web UI.lnk'))
$shortcut.TargetPath = 'powershell.exe'
$shortcut.Arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + $launcher + '"'
$shortcut.WorkingDirectory = $root
$shortcut.IconLocation = "$env:SystemRoot\System32\shell32.dll,220"
$shortcut.Save()
Write-Host 'Install complete. A Pi Web UI launcher shortcut was created on Desktop.'
Write-Host 'Configure OAuth/API keys separately on this computer.'
