param([switch]$SkipNpmInstall)
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$templateFile = Join-Path $root 'configs\pi-settings.template.json'
$agentDir = Join-Path $env:USERPROFILE '.pi\agent'
if (-not $SkipNpmInstall) { npm install -g '@earendil-works/pi-coding-agent@0.85.1' 'pi-web-ui@0.81.0' }
if (-not (Get-Command pi -ErrorAction SilentlyContinue) -or -not (Get-Command pi-web-ui -ErrorAction SilentlyContinue)) { throw 'pi or pi-web-ui was not found.' }
New-Item -ItemType Directory -Force -Path $agentDir | Out-Null
$template = Get-Content $templateFile -Raw -Encoding UTF8 | ConvertFrom-Json
$settingsFile = Join-Path $agentDir 'settings.json'
$current = if (Test-Path $settingsFile) { Get-Content $settingsFile -Raw -Encoding UTF8 | ConvertFrom-Json } else { [pscustomobject]@{} }
foreach ($p in $template.PSObject.Properties) { $current | Add-Member -Force NoteProperty $p.Name $p.Value }
$current | ConvertTo-Json -Depth 20 | Set-Content $settingsFile -Encoding UTF8
node (Join-Path $root 'scripts\install-codex-usage-plugin.js')
node (Join-Path $root 'scripts\apply-pi-web-ui-profile.js')
$launcher = Join-Path $root 'scripts\pi-web-ui-launcher.ps1'
$desktop = [Environment]::GetFolderPath('Desktop')
$shortcut = (New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $desktop 'Pi Web UI.lnk'))
$shortcut.TargetPath = 'powershell.exe'
$shortcut.Arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + $launcher + '"'
$shortcut.WorkingDirectory = $root
$shortcut.IconLocation = "$env:SystemRoot\System32\shell32.dll,220"
$shortcut.Save()
Write-Host 'Install complete. A Pi Web UI launcher shortcut was created on Desktop.'
Write-Host 'Configure OAuth/API keys separately on this computer.'
