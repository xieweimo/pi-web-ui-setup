﻿# pi 网页版一键启动器（主版本，位于 PIwork/scripts/）
# 用法：双击桌面「启动 Pi 网页版」图标，或直接运行本脚本
# 行为：启动服务（若未运行）→ 打开浏览器 → 全部标签页关闭满 3 分钟后自动停服
$ErrorActionPreference = 'SilentlyContinue'

# ---- 可配置项 ----
$cwd       = Split-Path $PSScriptRoot -Parent                 # 工作目录（仓库迁移后自动适配）
$shim      = Join-Path $env:APPDATA 'npm\pi-web-ui.cmd'      # pi-web-ui 启动命令（默认：npm 全局目录）
$port      = 8787                                         # 服务端口
$idleLimit = 180                                          # 浏览器无连接多少秒后停服（容忍休眠/后台标签）
$waitReady = 20                                           # 等待端口就绪的最长秒数

# 便携安装（学校机房等无管理员环境）会在仓库根写 install.json，记录便携 Node 与
# pi-web-ui 启动命令的真实路径；便携 Node 不在系统 PATH，必须先注入再启动服务。
$installCfg = Join-Path $cwd 'install.json'
if (Test-Path $installCfg) {
    try {
        $ic = Get-Content $installCfg -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($ic.nodeDir -and (Test-Path $ic.nodeDir)) { $env:PATH = "$($ic.nodeDir);$env:PATH" }
        if ($ic.shim -and (Test-Path $ic.shim)) { $shim = $ic.shim }
    } catch { }
}
if (-not (Test-Path $shim)) {
    $cmd = Get-Command pi-web-ui -ErrorAction SilentlyContinue
    if ($cmd) { $shim = $cmd.Source }
}

function Test-Listening {
    return [bool](Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue)
}

# 0. 检查启动命令是否存在
if (-not (Test-Path $shim)) {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show("找不到 pi-web-ui 启动命令：`n$shim`n请先运行安装器（install.ps1）或执行 npm install -g pi-web-ui。", 'pi-web-ui')
    exit 1
}

# 0.5 代理注入（重要）
# pi 的 Codex / OpenAI 请求从【进程环境变量】读代理（https_proxy / all_proxy），
# 而 pi-web-ui 服务自己不会去读 pi 的 settings.json —— 不注入就会出现
# 「大模型 API 出错，正在自动重试：fetch failed」（国内直连 chatgpt.com 失败）。
# 这里把 pi 全局设置里的 httpProxy 注入本进程，下面的 Start-Process 子进程会继承。
$piSettings = Join-Path $env:USERPROFILE '.pi\agent\settings.json'
if (Test-Path $piSettings) {
    try {
        $proxy = (Get-Content $piSettings -Raw | ConvertFrom-Json).httpProxy
        if ($proxy) {
            if (-not $env:HTTP_PROXY)  { $env:HTTP_PROXY  = $proxy }
            if (-not $env:HTTPS_PROXY) { $env:HTTPS_PROXY = $proxy }
            # 本机服务 / 浏览器回连绝不能绕到代理，否则 127.0.0.1:8787 会返回 502。
            $localNoProxy = 'localhost,127.0.0.1,::1'
            $env:NO_PROXY = if ($env:NO_PROXY) { "$($env:NO_PROXY),$localNoProxy" } else { $localNoProxy }
            $env:no_proxy = $env:NO_PROXY
        }
    } catch { }
}

# 0.6 为插件补充逐条 usageCost（用于剔除 Codex 订阅的理论 API 成本）。
# npm 升级会覆盖 pi-web-ui/dist；启动前幂等重打补丁，失败不阻断主服务。
$usageCostPatch = Join-Path $cwd 'patches\patch-pi-web-ui-usage-cost.js'
$liveModelPatch = Join-Path $cwd 'patches\patch-pi-web-ui-plugin-live-model.js'
$recoveryUiPatch = Join-Path $cwd 'patches\patch-pi-web-ui-recovery-ui.js'
$recoveryWatchdog = Join-Path $cwd 'scripts\pi-web-ui-recovery-watchdog.js'
$stopButtonPatch = Join-Path $cwd 'patches\apply-stop-button.ps1'
foreach ($patch in @($usageCostPatch, $liveModelPatch, $recoveryUiPatch)) {
    if ((Test-Path $patch) -and (Get-Command node -ErrorAction SilentlyContinue)) { & node $patch | Out-Null }
}
# 停止按钮样式属于静态网页资源；npm 升级覆盖后启动时幂等恢复。
if (Test-Path $stopButtonPatch) {
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $stopButtonPatch | Out-Null
}

# 独立守护端口：网页断连后仍可请求它重启 8787 服务。
# 便携 Node 不在系统 PATH，优先用 install.json 里的绝对路径。
if ((Test-Path $recoveryWatchdog) -and -not (Get-NetTCPConnection -LocalPort 8788 -State Listen -ErrorAction SilentlyContinue)) {
    $nodeExe = if (Test-Path (Join-Path (Split-Path $PSScriptRoot -Parent) 'node\node.exe')) {
        Join-Path (Split-Path $PSScriptRoot -Parent) 'node\node.exe'
    } else { 'node.exe' }
    Start-Process -FilePath $nodeExe -ArgumentList $recoveryWatchdog -WindowStyle Hidden
}

# 1. 仅在服务未运行时启动（避免重复实例）
if (-not (Test-Listening)) {
    Start-Process -FilePath 'cmd.exe' -ArgumentList '/c', $shim, '--no-browser', '--cwd', $cwd -WindowStyle Hidden | Out-Null

    $ready = $false
    for ($i = 0; $i -lt $waitReady; $i++) {
        if (Test-Listening) { $ready = $true; break }
        Start-Sleep -Seconds 1
    }
    if (-not $ready) {
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.MessageBox]::Show('pi-web-ui 启动失败，请重试。', 'pi-web-ui')
        exit 1
    }
}

# 2. 打开默认浏览器
Start-Process "http://localhost:$port"
Start-Sleep -Seconds 5

# 3. 监听连接：仅当浏览器无连接满 $idleLimit 秒后才停服。
#    临时断开（休眠、后台标签、刷新）会重置计数，避免误停。
$idle = 0
while ($true) {
    $est = Get-NetTCPConnection -LocalPort $port -State Established -ErrorAction SilentlyContinue
    if ($est) { $idle = 0 } else { $idle++ }
    if ($idle -ge $idleLimit) { break }
    Start-Sleep -Seconds 1
}

# 4. 停服
Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue |
    ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }
