#!/usr/bin/env node
// 给「从最近项目移出」加成功提示（升级 pi-web-ui 后执行一次）
// 效果：点击移出后顶部弹出「已从最近项目列表移除（项目文件未删除）」，明确反馈
const fs = require('fs');
const path = require('path');

const p = path.join(process.env.APPDATA || '', 'npm', 'node_modules', 'pi-web-ui', 'dist', 'server', 'agent-service.js');
if (!fs.existsSync(p)) { console.error('✗ 未找到 ' + p); process.exit(1); }

let s = fs.readFileSync(p, 'utf8');
if (s.includes('已从最近项目列表移除')) {
  console.log('✓ 已含提示，跳过');
  process.exit(0);
}

const OLD = '    async removeProject(path) {\n' +
  '        this.stateStore.removeProject(this.clientId, path);\n' +
  '        await this.pushProjects();\n' +
  '    }';
const NEW = '    async removeProject(path) {\n' +
  '        this.stateStore.removeProject(this.clientId, path);\n' +
  '        await this.pushProjects();\n' +
  '        this.emit({\n' +
  '            type: "notice",\n' +
  '            level: "info",\n' +
  '            text: "已从最近项目列表移除（项目文件未删除）",\n' +
  '            textEn: "Removed from recent projects (project files are NOT deleted)",\n' +
  '        });\n' +
  '    }';

if (!s.includes(OLD)) { console.error('✗ 未找到 removeProject 目标代码（pi-web-ui 版本可能已变，需人工核对）'); process.exit(1); }
s = s.replace(OLD, NEW);
fs.writeFileSync(p, s, 'utf8');
console.log('✓ 已给「移出项目」加成功提示。重启 pi-web-ui 后生效。');
